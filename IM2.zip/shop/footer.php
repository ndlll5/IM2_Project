</div>
    <footer class="footer mt-auto py-3 text-white text-center">
        <hr style="background-color: #f0f0f0; border-top: 1px solid #555555;" />
        <div class="social-icons mt-3">
            <a href="https://www.facebook.com/motoracertradingwholesalesupply" target="_blank" class="text-white mx-2"><i class="fab fa-facebook-f fa-lg"></i></a>
            <a href="https://www.tiktok.com/@motoracertrading" target="_blank" class="text-white mx-2"><i class="fab fa-tiktok fa-lg"></i></a>
            <a href="https://www.instagram.com/butuanmotoracer/" target="_blank" class="text-white mx-2"><i class="fab fa-instagram fa-lg"></i></a>
        </div>
        <div class="cont mt-3">
            <span>&copy; <?php echo date("Y"); ?> Motoracer. All rights reserved.</span>
        </div>
    </footer>
</body>
</html>
